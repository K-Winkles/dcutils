# Common utilities for data center functions

1. Move batch
    Indicate parent folder and this script will move all files under that parent folder from a source bucket to a destination bucket.

2. Move 
    Indicate source blob and destination blob. This script will copy the blob but it will NOT delete.
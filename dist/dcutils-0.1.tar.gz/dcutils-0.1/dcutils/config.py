SRC_BUCKET = 'senti-storage-01'
DEST_BUCKET = 'senti-data-center-staging'
DEST_BLOB = 'products/natter/text/raw'
PARENT_FOLDER = 'datasets'